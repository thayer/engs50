/* two.h */

int two = 2;
extern int thing_two(void);
