/* one.c */

#include "one.h"

int thing_one(void)
{
  return one;
}

