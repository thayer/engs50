/* two.c */

#include "two.h"

int thing_two(void)
{
  return two;
}

