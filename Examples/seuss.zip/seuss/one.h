/* one.h */

int one = 1;
extern int thing_one(void);
